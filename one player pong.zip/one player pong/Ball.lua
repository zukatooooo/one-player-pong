Ball = Class{}

function Ball:init()
    self.x = VIRTUAL_WIDTH / 2 - BALL_SIZE / 2
    self.y = VIRTUAL_HEIGHT / 2 - BALL_SIZE / 2
    self.dx = math.random(2) == 1 and -100 or 100
    self.dy = math.random(-50, 50)
end

function Ball:update(dt)
    self.x = self.x + self.dx * dt
    self.y = self.y + self.dy * dt

    if self.x <= 0 or self.x + BALL_SIZE >= VIRTUAL_WIDTH then
        self.dx = -self.dx
        hit:play()
    end

    if self.y <= 0 then
        self.dy = -self.dy
        hit:play()
    end

    if ball:collides(player) then
        ball.dy = -ball.dy

        local ballCenterX = self.x + BALL_SIZE / 2
        local paddleCenterX = player.x + PADDLE_WIDTH / 2

        local collisionOffset = ballCenterX - paddleCenterX

        ball.dx = ball.dx + collisionOffset * 5

        scoreSounde:play()
    end


    if ball:collides(player) then
        ball.dy = -ball.dy
        score = score + 1
    end

    if self.y + BALL_SIZE >= VIRTUAL_HEIGHT then
        self:reset()
        death:play()
    end
end

function Ball:collides(paddle)
    return not (self.x + BALL_SIZE < paddle.x or self.x > paddle.x + PADDLE_WIDTH or
                self.y + BALL_SIZE < paddle.y or self.y > paddle.y + PADDLE_HEIGHT)
end

function Ball:reset()
    self.x = VIRTUAL_WIDTH / 2 - BALL_SIZE / 2
    self.y = VIRTUAL_HEIGHT / 2 - BALL_SIZE / 2
    self.dx = math.random(2) == 1 and -100 or 100
    self.dy = math.random(-50, 50)
end

function Ball:render()
    love.graphics.rectangle("fill", self.x, self.y, BALL_SIZE, BALL_SIZE)
end
