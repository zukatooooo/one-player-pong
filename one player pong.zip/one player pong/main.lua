Class = require 'class'
push = require 'push'

require 'Player'
require 'Ball'

Class = require("class")
push = require("push")

WINDOW_WIDTH = 640
WINDOW_HEIGHT = 480
VIRTUAL_WIDTH = 432
VIRTUAL_HEIGHT = 243

PADDLE_WIDTH = 80
PADDLE_HEIGHT = 20
BALL_SIZE = 10

PLAYER_SPEED = 200

score = 0

function love.load()
    love.window.setTitle("one player pong")
    love.graphics.setDefaultFilter("nearest", "nearest")
    push:setupScreen(VIRTUAL_WIDTH, VIRTUAL_HEIGHT, WINDOW_WIDTH, WINDOW_HEIGHT, {
        fullscreen = false,
        resizable = true,
        vsync = true
    })

    font = love.graphics.newFont("font.ttf", 10)
    love.graphics.setFont(font)

    scoreSounde = love.audio.newSource("sounds/score.wav", "static")
    hit = love.audio.newSource("sounds/hitt.wav", "static")
    death = love.audio.newSource("sounds/death.wav", "static")

    ball = Ball()
    player = Player()
end

function love.update(dt)
    ball:update(dt)
    player:update(dt)

    if ball:collides(player) then
        ball.dy = -ball.dy
    end

    if ball.y + BALL_SIZE >= VIRTUAL_HEIGHT then
        ball:reset()
    end
end

function love.draw()
    push:start()
    love.graphics.clear(40 / 255, 45 / 255, 52 / 255, 1)

    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.print("Score: " .. score, 10, 10)

    ball:render()
    player:render()

    push:finish()
end

function love.resize(w, h)
    push:resize(w, h)
end