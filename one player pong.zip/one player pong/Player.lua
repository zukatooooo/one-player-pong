Player = Class{}

function Player:init()
    self.x = VIRTUAL_WIDTH / 2 - PADDLE_WIDTH / 2
    self.y = VIRTUAL_HEIGHT - PADDLE_HEIGHT
    self.dx = 0
end

function Player:update(dt)
    if love.keyboard.isDown("left") then
        self.dx = -PLAYER_SPEED
    elseif love.keyboard.isDown("right") then
        self.dx = PLAYER_SPEED
    else
        self.dx = 0
    end

    self.x = math.max(0, math.min(VIRTUAL_WIDTH - PADDLE_WIDTH, self.x + self.dx * dt))
end

function Player:render()
    love.graphics.rectangle("fill", self.x, self.y, PADDLE_WIDTH, PADDLE_HEIGHT)
end
